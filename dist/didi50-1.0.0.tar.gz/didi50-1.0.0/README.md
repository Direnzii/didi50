# didi50

**didi50** é uma simples ferramenta de envio de requests em massa de forma assincrona
usado para testar scalonamento de tasks, desempenho de servidores, entre outros... (Por sua conta em risco)

Criei ela com base na ferramenta de DOS T50, mas como a T50 tava complicada demais para o que eu queria, criei esse trem

# Funções

* `envio de requests em massa dado a quantidade de request desejada e a URL` - É para voce ver... é só isso !!